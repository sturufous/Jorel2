package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class GeopoliticalTypes.
 * @see ca.bc.gov.tno.jorel2.model.GeopoliticalTypes
 * @author Hibernate Tools
 */
@Stateless
public class GeopoliticalTypesHome {

	private static final Log log = LogFactory.getLog(GeopoliticalTypesHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(GeopoliticalTypes transientInstance) {
		log.debug("persisting GeopoliticalTypes instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(GeopoliticalTypes persistentInstance) {
		log.debug("removing GeopoliticalTypes instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public GeopoliticalTypes merge(GeopoliticalTypes detachedInstance) {
		log.debug("merging GeopoliticalTypes instance");
		try {
			GeopoliticalTypes result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public GeopoliticalTypes findById(BigDecimal id) {
		log.debug("getting GeopoliticalTypes instance with id: " + id);
		try {
			GeopoliticalTypes instance = entityManager.find(GeopoliticalTypes.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
