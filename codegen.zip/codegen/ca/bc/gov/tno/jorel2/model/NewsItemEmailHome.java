package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class NewsItemEmail.
 * @see ca.bc.gov.tno.jorel2.model.NewsItemEmail
 * @author Hibernate Tools
 */
@Stateless
public class NewsItemEmailHome {

	private static final Log log = LogFactory.getLog(NewsItemEmailHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(NewsItemEmail transientInstance) {
		log.debug("persisting NewsItemEmail instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(NewsItemEmail persistentInstance) {
		log.debug("removing NewsItemEmail instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public NewsItemEmail merge(NewsItemEmail detachedInstance) {
		log.debug("merging NewsItemEmail instance");
		try {
			NewsItemEmail result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public NewsItemEmail findById(NewsItemEmailId id) {
		log.debug("getting NewsItemEmail instance with id: " + id);
		try {
			NewsItemEmail instance = entityManager.find(NewsItemEmail.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
