package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.util.Date;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class AlertTrigger.
 * @see ca.bc.gov.tno.jorel2.model.AlertTrigger
 * @author Hibernate Tools
 */
@Stateless
public class AlertTriggerHome {

	private static final Log log = LogFactory.getLog(AlertTriggerHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(AlertTrigger transientInstance) {
		log.debug("persisting AlertTrigger instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(AlertTrigger persistentInstance) {
		log.debug("removing AlertTrigger instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public AlertTrigger merge(AlertTrigger detachedInstance) {
		log.debug("merging AlertTrigger instance");
		try {
			AlertTrigger result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public AlertTrigger findById(Date id) {
		log.debug("getting AlertTrigger instance with id: " + id);
		try {
			AlertTrigger instance = entityManager.find(AlertTrigger.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
