package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class FilesImported.
 * @see ca.bc.gov.tno.jorel2.model.FilesImported
 * @author Hibernate Tools
 */
@Stateless
public class FilesImportedHome {

	private static final Log log = LogFactory.getLog(FilesImportedHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(FilesImported transientInstance) {
		log.debug("persisting FilesImported instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(FilesImported persistentInstance) {
		log.debug("removing FilesImported instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public FilesImported merge(FilesImported detachedInstance) {
		log.debug("merging FilesImported instance");
		try {
			FilesImported result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public FilesImported findById(BigDecimal id) {
		log.debug("getting FilesImported instance with id: " + id);
		try {
			FilesImported instance = entityManager.find(FilesImported.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
