package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class FilterIssues.
 * @see ca.bc.gov.tno.jorel2.model.FilterIssues
 * @author Hibernate Tools
 */
@Stateless
public class FilterIssuesHome {

	private static final Log log = LogFactory.getLog(FilterIssuesHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(FilterIssues transientInstance) {
		log.debug("persisting FilterIssues instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(FilterIssues persistentInstance) {
		log.debug("removing FilterIssues instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public FilterIssues merge(FilterIssues detachedInstance) {
		log.debug("merging FilterIssues instance");
		try {
			FilterIssues result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public FilterIssues findById(FilterIssuesId id) {
		log.debug("getting FilterIssues instance with id: " + id);
		try {
			FilterIssues instance = entityManager.find(FilterIssues.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
