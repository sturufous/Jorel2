package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class HnewsItems.
 * @see ca.bc.gov.tno.jorel2.model.HnewsItems
 * @author Hibernate Tools
 */
@Stateless
public class HnewsItemsHome {

	private static final Log log = LogFactory.getLog(HnewsItemsHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(HnewsItems transientInstance) {
		log.debug("persisting HnewsItems instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(HnewsItems persistentInstance) {
		log.debug("removing HnewsItems instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public HnewsItems merge(HnewsItems detachedInstance) {
		log.debug("merging HnewsItems instance");
		try {
			HnewsItems result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public HnewsItems findById(BigDecimal id) {
		log.debug("getting HnewsItems instance with id: " + id);
		try {
			HnewsItems instance = entityManager.find(HnewsItems.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
