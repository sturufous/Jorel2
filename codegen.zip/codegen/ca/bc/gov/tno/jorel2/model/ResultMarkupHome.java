package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class ResultMarkup.
 * @see ca.bc.gov.tno.jorel2.model.ResultMarkup
 * @author Hibernate Tools
 */
@Stateless
public class ResultMarkupHome {

	private static final Log log = LogFactory.getLog(ResultMarkupHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(ResultMarkup transientInstance) {
		log.debug("persisting ResultMarkup instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(ResultMarkup persistentInstance) {
		log.debug("removing ResultMarkup instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public ResultMarkup merge(ResultMarkup detachedInstance) {
		log.debug("merging ResultMarkup instance");
		try {
			ResultMarkup result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public ResultMarkup findById(ResultMarkupId id) {
		log.debug("getting ResultMarkup instance with id: " + id);
		try {
			ResultMarkup instance = entityManager.find(ResultMarkup.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
