package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class RollingThemes.
 * @see ca.bc.gov.tno.jorel2.model.RollingThemes
 * @author Hibernate Tools
 */
@Stateless
public class RollingThemesHome {

	private static final Log log = LogFactory.getLog(RollingThemesHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(RollingThemes transientInstance) {
		log.debug("persisting RollingThemes instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(RollingThemes persistentInstance) {
		log.debug("removing RollingThemes instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public RollingThemes merge(RollingThemes detachedInstance) {
		log.debug("merging RollingThemes instance");
		try {
			RollingThemes result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public RollingThemes findById(RollingThemesId id) {
		log.debug("getting RollingThemes instance with id: " + id);
		try {
			RollingThemes instance = entityManager.find(RollingThemes.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
