package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final


import Dr.headlineIndex3.i;
import ca.bc.gov.tno.jorel2.model.Dr.headlineIndex3.iId;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class i.
 * @see ca.bc.gov.tno.jorel2.model.Dr.headlineIndex3.i
 * @author Hibernate Tools
 */
@Stateless
public class iHome {

    private static final Log log = LogFactory.getLog(Dr.headlineIndex3.iHome.class);

    @PersistenceContext private EntityManager entityManager;
    
    public void persist(i transientInstance) {
        log.debug("persisting i instance");
        try {
            entityManager.persist(transientInstance);
            log.debug("persist successful");
        }
        catch (RuntimeException re) {
            log.error("persist failed", re);
            throw re;
        }
    }
    
    public void remove(i persistentInstance) {
        log.debug("removing i instance");
        try {
            entityManager.remove(persistentInstance);
            log.debug("remove successful");
        }
        catch (RuntimeException re) {
            log.error("remove failed", re);
            throw re;
        }
    }
    
    public i merge(i detachedInstance) {
        log.debug("merging i instance");
        try {
            i result = entityManager.merge(detachedInstance);
            log.debug("merge successful");
            return result;
        }
        catch (RuntimeException re) {
            log.error("merge failed", re);
            throw re;
        }
    }
    
    public i findById( Dr.headlineIndex3.iId id) {
        log.debug("getting i instance with id: " + id);
        try {
            i instance = entityManager.find(Dr.headlineIndex3.i.class, id);
            log.debug("get successful");
            return instance;
        }
        catch (RuntimeException re) {
            log.error("get failed", re);
            throw re;
        }
    }
}

