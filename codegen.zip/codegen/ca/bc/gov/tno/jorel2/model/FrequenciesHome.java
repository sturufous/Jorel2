package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class Frequencies.
 * @see ca.bc.gov.tno.jorel2.model.Frequencies
 * @author Hibernate Tools
 */
@Stateless
public class FrequenciesHome {

	private static final Log log = LogFactory.getLog(FrequenciesHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(Frequencies transientInstance) {
		log.debug("persisting Frequencies instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(Frequencies persistentInstance) {
		log.debug("removing Frequencies instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public Frequencies merge(Frequencies detachedInstance) {
		log.debug("merging Frequencies instance");
		try {
			Frequencies result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public Frequencies findById(BigDecimal id) {
		log.debug("getting Frequencies instance with id: " + id);
		try {
			Frequencies instance = entityManager.find(Frequencies.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
