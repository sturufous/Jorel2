package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class TonePool.
 * @see ca.bc.gov.tno.jorel2.model.TonePool
 * @author Hibernate Tools
 */
@Stateless
public class TonePoolHome {

	private static final Log log = LogFactory.getLog(TonePoolHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(TonePool transientInstance) {
		log.debug("persisting TonePool instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(TonePool persistentInstance) {
		log.debug("removing TonePool instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public TonePool merge(TonePool detachedInstance) {
		log.debug("merging TonePool instance");
		try {
			TonePool result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public TonePool findById(BigDecimal id) {
		log.debug("getting TonePool instance with id: " + id);
		try {
			TonePool instance = entityManager.find(TonePool.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
