package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class Preferences.
 * @see ca.bc.gov.tno.jorel2.model.Preferences
 * @author Hibernate Tools
 */
@Stateless
public class PreferencesHome {

	private static final Log log = LogFactory.getLog(PreferencesHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(Preferences transientInstance) {
		log.debug("persisting Preferences instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(Preferences persistentInstance) {
		log.debug("removing Preferences instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public Preferences merge(Preferences detachedInstance) {
		log.debug("merging Preferences instance");
		try {
			Preferences result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public Preferences findById(BigDecimal id) {
		log.debug("getting Preferences instance with id: " + id);
		try {
			Preferences instance = entityManager.find(Preferences.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
