package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class NewsItemQuotes.
 * @see ca.bc.gov.tno.jorel2.model.NewsItemQuotes
 * @author Hibernate Tools
 */
@Stateless
public class NewsItemQuotesHome {

	private static final Log log = LogFactory.getLog(NewsItemQuotesHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(NewsItemQuotes transientInstance) {
		log.debug("persisting NewsItemQuotes instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(NewsItemQuotes persistentInstance) {
		log.debug("removing NewsItemQuotes instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public NewsItemQuotes merge(NewsItemQuotes detachedInstance) {
		log.debug("merging NewsItemQuotes instance");
		try {
			NewsItemQuotes result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public NewsItemQuotes findById(BigDecimal id) {
		log.debug("getting NewsItemQuotes instance with id: " + id);
		try {
			NewsItemQuotes instance = entityManager.find(NewsItemQuotes.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
