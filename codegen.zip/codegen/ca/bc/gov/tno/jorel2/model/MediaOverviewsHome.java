package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class MediaOverviews.
 * @see ca.bc.gov.tno.jorel2.model.MediaOverviews
 * @author Hibernate Tools
 */
@Stateless
public class MediaOverviewsHome {

	private static final Log log = LogFactory.getLog(MediaOverviewsHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(MediaOverviews transientInstance) {
		log.debug("persisting MediaOverviews instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(MediaOverviews persistentInstance) {
		log.debug("removing MediaOverviews instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public MediaOverviews merge(MediaOverviews detachedInstance) {
		log.debug("merging MediaOverviews instance");
		try {
			MediaOverviews result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public MediaOverviews findById(BigDecimal id) {
		log.debug("getting MediaOverviews instance with id: " + id);
		try {
			MediaOverviews instance = entityManager.find(MediaOverviews.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
