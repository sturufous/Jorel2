package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class Sources.
 * @see ca.bc.gov.tno.jorel2.model.Sources
 * @author Hibernate Tools
 */
@Stateless
public class SourcesHome {

	private static final Log log = LogFactory.getLog(SourcesHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(Sources transientInstance) {
		log.debug("persisting Sources instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(Sources persistentInstance) {
		log.debug("removing Sources instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public Sources merge(Sources detachedInstance) {
		log.debug("merging Sources instance");
		try {
			Sources result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public Sources findById(BigDecimal id) {
		log.debug("getting Sources instance with id: " + id);
		try {
			Sources instance = entityManager.find(Sources.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
