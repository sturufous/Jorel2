package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class ReportStories.
 * @see ca.bc.gov.tno.jorel2.model.ReportStories
 * @author Hibernate Tools
 */
@Stateless
public class ReportStoriesHome {

	private static final Log log = LogFactory.getLog(ReportStoriesHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(ReportStories transientInstance) {
		log.debug("persisting ReportStories instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(ReportStories persistentInstance) {
		log.debug("removing ReportStories instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public ReportStories merge(ReportStories detachedInstance) {
		log.debug("merging ReportStories instance");
		try {
			ReportStories result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public ReportStories findById(BigDecimal id) {
		log.debug("getting ReportStories instance with id: " + id);
		try {
			ReportStories instance = entityManager.find(ReportStories.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
