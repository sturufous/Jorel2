package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class FileLock.
 * @see ca.bc.gov.tno.jorel2.model.FileLock
 * @author Hibernate Tools
 */
@Stateless
public class FileLockHome {

	private static final Log log = LogFactory.getLog(FileLockHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(FileLock transientInstance) {
		log.debug("persisting FileLock instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(FileLock persistentInstance) {
		log.debug("removing FileLock instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public FileLock merge(FileLock detachedInstance) {
		log.debug("merging FileLock instance");
		try {
			FileLock result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public FileLock findById(BigDecimal id) {
		log.debug("getting FileLock instance with id: " + id);
		try {
			FileLock instance = entityManager.find(FileLock.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
