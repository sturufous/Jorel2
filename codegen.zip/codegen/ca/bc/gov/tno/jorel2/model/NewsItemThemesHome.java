package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class NewsItemThemes.
 * @see ca.bc.gov.tno.jorel2.model.NewsItemThemes
 * @author Hibernate Tools
 */
@Stateless
public class NewsItemThemesHome {

	private static final Log log = LogFactory.getLog(NewsItemThemesHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(NewsItemThemes transientInstance) {
		log.debug("persisting NewsItemThemes instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(NewsItemThemes persistentInstance) {
		log.debug("removing NewsItemThemes instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public NewsItemThemes merge(NewsItemThemes detachedInstance) {
		log.debug("merging NewsItemThemes instance");
		try {
			NewsItemThemes result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public NewsItemThemes findById(NewsItemThemesId id) {
		log.debug("getting NewsItemThemes instance with id: " + id);
		try {
			NewsItemThemes instance = entityManager.find(NewsItemThemes.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
