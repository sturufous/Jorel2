package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class Demographic.
 * @see ca.bc.gov.tno.jorel2.model.Demographic
 * @author Hibernate Tools
 */
@Stateless
public class DemographicHome {

	private static final Log log = LogFactory.getLog(DemographicHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(Demographic transientInstance) {
		log.debug("persisting Demographic instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(Demographic persistentInstance) {
		log.debug("removing Demographic instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public Demographic merge(Demographic detachedInstance) {
		log.debug("merging Demographic instance");
		try {
			Demographic result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public Demographic findById(BigDecimal id) {
		log.debug("getting Demographic instance with id: " + id);
		try {
			Demographic instance = entityManager.find(Demographic.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
