package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class Placenames.
 * @see ca.bc.gov.tno.jorel2.model.Placenames
 * @author Hibernate Tools
 */
@Stateless
public class PlacenamesHome {

	private static final Log log = LogFactory.getLog(PlacenamesHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(Placenames transientInstance) {
		log.debug("persisting Placenames instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(Placenames persistentInstance) {
		log.debug("removing Placenames instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public Placenames merge(Placenames detachedInstance) {
		log.debug("merging Placenames instance");
		try {
			Placenames result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public Placenames findById(BigDecimal id) {
		log.debug("getting Placenames instance with id: " + id);
		try {
			Placenames instance = entityManager.find(Placenames.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
