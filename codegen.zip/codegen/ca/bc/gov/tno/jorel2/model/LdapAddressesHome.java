package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class LdapAddresses.
 * @see ca.bc.gov.tno.jorel2.model.LdapAddresses
 * @author Hibernate Tools
 */
@Stateless
public class LdapAddressesHome {

	private static final Log log = LogFactory.getLog(LdapAddressesHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(LdapAddresses transientInstance) {
		log.debug("persisting LdapAddresses instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(LdapAddresses persistentInstance) {
		log.debug("removing LdapAddresses instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public LdapAddresses merge(LdapAddresses detachedInstance) {
		log.debug("merging LdapAddresses instance");
		try {
			LdapAddresses result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public LdapAddresses findById(BigDecimal id) {
		log.debug("getting LdapAddresses instance with id: " + id);
		try {
			LdapAddresses instance = entityManager.find(LdapAddresses.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
