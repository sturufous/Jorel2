package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class ReportExecSummary.
 * @see ca.bc.gov.tno.jorel2.model.ReportExecSummary
 * @author Hibernate Tools
 */
@Stateless
public class ReportExecSummaryHome {

	private static final Log log = LogFactory.getLog(ReportExecSummaryHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(ReportExecSummary transientInstance) {
		log.debug("persisting ReportExecSummary instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(ReportExecSummary persistentInstance) {
		log.debug("removing ReportExecSummary instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public ReportExecSummary merge(ReportExecSummary detachedInstance) {
		log.debug("merging ReportExecSummary instance");
		try {
			ReportExecSummary result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public ReportExecSummary findById(BigDecimal id) {
		log.debug("getting ReportExecSummary instance with id: " + id);
		try {
			ReportExecSummary instance = entityManager.find(ReportExecSummary.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
