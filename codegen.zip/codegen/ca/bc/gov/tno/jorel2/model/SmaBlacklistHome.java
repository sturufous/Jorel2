package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class SmaBlacklist.
 * @see ca.bc.gov.tno.jorel2.model.SmaBlacklist
 * @author Hibernate Tools
 */
@Stateless
public class SmaBlacklistHome {

	private static final Log log = LogFactory.getLog(SmaBlacklistHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(SmaBlacklist transientInstance) {
		log.debug("persisting SmaBlacklist instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(SmaBlacklist persistentInstance) {
		log.debug("removing SmaBlacklist instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public SmaBlacklist merge(SmaBlacklist detachedInstance) {
		log.debug("merging SmaBlacklist instance");
		try {
			SmaBlacklist result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public SmaBlacklist findById(BigDecimal id) {
		log.debug("getting SmaBlacklist instance with id: " + id);
		try {
			SmaBlacklist instance = entityManager.find(SmaBlacklist.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
