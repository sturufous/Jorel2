package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class UserActivityLog.
 * @see ca.bc.gov.tno.jorel2.model.UserActivityLog
 * @author Hibernate Tools
 */
@Stateless
public class UserActivityLogHome {

	private static final Log log = LogFactory.getLog(UserActivityLogHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(UserActivityLog transientInstance) {
		log.debug("persisting UserActivityLog instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(UserActivityLog persistentInstance) {
		log.debug("removing UserActivityLog instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public UserActivityLog merge(UserActivityLog detachedInstance) {
		log.debug("merging UserActivityLog instance");
		try {
			UserActivityLog result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public UserActivityLog findById(BigDecimal id) {
		log.debug("getting UserActivityLog instance with id: " + id);
		try {
			UserActivityLog instance = entityManager.find(UserActivityLog.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
