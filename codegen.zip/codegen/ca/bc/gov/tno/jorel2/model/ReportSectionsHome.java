package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class ReportSections.
 * @see ca.bc.gov.tno.jorel2.model.ReportSections
 * @author Hibernate Tools
 */
@Stateless
public class ReportSectionsHome {

	private static final Log log = LogFactory.getLog(ReportSectionsHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(ReportSections transientInstance) {
		log.debug("persisting ReportSections instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(ReportSections persistentInstance) {
		log.debug("removing ReportSections instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public ReportSections merge(ReportSections detachedInstance) {
		log.debug("merging ReportSections instance");
		try {
			ReportSections result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public ReportSections findById(BigDecimal id) {
		log.debug("getting ReportSections instance with id: " + id);
		try {
			ReportSections instance = entityManager.find(ReportSections.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
