package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class NewsItemDepartments.
 * @see ca.bc.gov.tno.jorel2.model.NewsItemDepartments
 * @author Hibernate Tools
 */
@Stateless
public class NewsItemDepartmentsHome {

	private static final Log log = LogFactory.getLog(NewsItemDepartmentsHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(NewsItemDepartments transientInstance) {
		log.debug("persisting NewsItemDepartments instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(NewsItemDepartments persistentInstance) {
		log.debug("removing NewsItemDepartments instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public NewsItemDepartments merge(NewsItemDepartments detachedInstance) {
		log.debug("merging NewsItemDepartments instance");
		try {
			NewsItemDepartments result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public NewsItemDepartments findById(NewsItemDepartmentsId id) {
		log.debug("getting NewsItemDepartments instance with id: " + id);
		try {
			NewsItemDepartments instance = entityManager.find(NewsItemDepartments.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
