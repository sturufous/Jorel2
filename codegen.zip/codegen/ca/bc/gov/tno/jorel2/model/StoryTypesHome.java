package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class StoryTypes.
 * @see ca.bc.gov.tno.jorel2.model.StoryTypes
 * @author Hibernate Tools
 */
@Stateless
public class StoryTypesHome {

	private static final Log log = LogFactory.getLog(StoryTypesHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(StoryTypes transientInstance) {
		log.debug("persisting StoryTypes instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(StoryTypes persistentInstance) {
		log.debug("removing StoryTypes instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public StoryTypes merge(StoryTypes detachedInstance) {
		log.debug("merging StoryTypes instance");
		try {
			StoryTypes result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public StoryTypes findById(BigDecimal id) {
		log.debug("getting StoryTypes instance with id: " + id);
		try {
			StoryTypes instance = entityManager.find(StoryTypes.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
