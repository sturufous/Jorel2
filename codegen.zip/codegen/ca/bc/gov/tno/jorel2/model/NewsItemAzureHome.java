package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class NewsItemAzure.
 * @see ca.bc.gov.tno.jorel2.model.NewsItemAzure
 * @author Hibernate Tools
 */
@Stateless
public class NewsItemAzureHome {

	private static final Log log = LogFactory.getLog(NewsItemAzureHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(NewsItemAzure transientInstance) {
		log.debug("persisting NewsItemAzure instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(NewsItemAzure persistentInstance) {
		log.debug("removing NewsItemAzure instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public NewsItemAzure merge(NewsItemAzure detachedInstance) {
		log.debug("merging NewsItemAzure instance");
		try {
			NewsItemAzure result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public NewsItemAzure findById(BigDecimal id) {
		log.debug("getting NewsItemAzure instance with id: " + id);
		try {
			NewsItemAzure instance = entityManager.find(NewsItemAzure.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
