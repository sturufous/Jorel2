package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class Influencers.
 * @see ca.bc.gov.tno.jorel2.model.Influencers
 * @author Hibernate Tools
 */
@Stateless
public class InfluencersHome {

	private static final Log log = LogFactory.getLog(InfluencersHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(Influencers transientInstance) {
		log.debug("persisting Influencers instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(Influencers persistentInstance) {
		log.debug("removing Influencers instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public Influencers merge(Influencers detachedInstance) {
		log.debug("merging Influencers instance");
		try {
			Influencers result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public Influencers findById(BigDecimal id) {
		log.debug("getting Influencers instance with id: " + id);
		try {
			Influencers instance = entityManager.find(Influencers.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
