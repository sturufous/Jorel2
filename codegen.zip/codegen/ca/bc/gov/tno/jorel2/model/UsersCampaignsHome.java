package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class UsersCampaigns.
 * @see ca.bc.gov.tno.jorel2.model.UsersCampaigns
 * @author Hibernate Tools
 */
@Stateless
public class UsersCampaignsHome {

	private static final Log log = LogFactory.getLog(UsersCampaignsHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(UsersCampaigns transientInstance) {
		log.debug("persisting UsersCampaigns instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(UsersCampaigns persistentInstance) {
		log.debug("removing UsersCampaigns instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public UsersCampaigns merge(UsersCampaigns detachedInstance) {
		log.debug("merging UsersCampaigns instance");
		try {
			UsersCampaigns result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public UsersCampaigns findById(UsersCampaignsId id) {
		log.debug("getting UsersCampaigns instance with id: " + id);
		try {
			UsersCampaigns instance = entityManager.find(UsersCampaigns.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
