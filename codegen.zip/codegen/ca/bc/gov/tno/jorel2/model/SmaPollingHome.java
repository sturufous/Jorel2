package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class SmaPolling.
 * @see ca.bc.gov.tno.jorel2.model.SmaPolling
 * @author Hibernate Tools
 */
@Stateless
public class SmaPollingHome {

	private static final Log log = LogFactory.getLog(SmaPollingHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(SmaPolling transientInstance) {
		log.debug("persisting SmaPolling instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(SmaPolling persistentInstance) {
		log.debug("removing SmaPolling instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public SmaPolling merge(SmaPolling detachedInstance) {
		log.debug("merging SmaPolling instance");
		try {
			SmaPolling result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public SmaPolling findById(BigDecimal id) {
		log.debug("getting SmaPolling instance with id: " + id);
		try {
			SmaPolling instance = entityManager.find(SmaPolling.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
