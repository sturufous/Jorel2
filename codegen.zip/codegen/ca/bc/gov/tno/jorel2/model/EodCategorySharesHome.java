package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class EodCategoryShares.
 * @see ca.bc.gov.tno.jorel2.model.EodCategoryShares
 * @author Hibernate Tools
 */
@Stateless
public class EodCategorySharesHome {

	private static final Log log = LogFactory.getLog(EodCategorySharesHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(EodCategoryShares transientInstance) {
		log.debug("persisting EodCategoryShares instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(EodCategoryShares persistentInstance) {
		log.debug("removing EodCategoryShares instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public EodCategoryShares merge(EodCategoryShares detachedInstance) {
		log.debug("merging EodCategoryShares instance");
		try {
			EodCategoryShares result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public EodCategoryShares findById(EodCategorySharesId id) {
		log.debug("getting EodCategoryShares instance with id: " + id);
		try {
			EodCategoryShares instance = entityManager.find(EodCategoryShares.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
