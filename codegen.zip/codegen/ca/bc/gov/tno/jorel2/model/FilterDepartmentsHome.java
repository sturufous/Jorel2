package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class FilterDepartments.
 * @see ca.bc.gov.tno.jorel2.model.FilterDepartments
 * @author Hibernate Tools
 */
@Stateless
public class FilterDepartmentsHome {

	private static final Log log = LogFactory.getLog(FilterDepartmentsHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(FilterDepartments transientInstance) {
		log.debug("persisting FilterDepartments instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(FilterDepartments persistentInstance) {
		log.debug("removing FilterDepartments instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public FilterDepartments merge(FilterDepartments detachedInstance) {
		log.debug("merging FilterDepartments instance");
		try {
			FilterDepartments result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public FilterDepartments findById(FilterDepartmentsId id) {
		log.debug("getting FilterDepartments instance with id: " + id);
		try {
			FilterDepartments instance = entityManager.find(FilterDepartments.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
