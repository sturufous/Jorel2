package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final


import Dr.textIndex3.s;
import ca.bc.gov.tno.jorel2.model.Dr.textIndex3.sId;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class s.
 * @see ca.bc.gov.tno.jorel2.model.Dr.textIndex3.s
 * @author Hibernate Tools
 */
@Stateless
public class sHome {

    private static final Log log = LogFactory.getLog(Dr.textIndex3.sHome.class);

    @PersistenceContext private EntityManager entityManager;
    
    public void persist(s transientInstance) {
        log.debug("persisting s instance");
        try {
            entityManager.persist(transientInstance);
            log.debug("persist successful");
        }
        catch (RuntimeException re) {
            log.error("persist failed", re);
            throw re;
        }
    }
    
    public void remove(s persistentInstance) {
        log.debug("removing s instance");
        try {
            entityManager.remove(persistentInstance);
            log.debug("remove successful");
        }
        catch (RuntimeException re) {
            log.error("remove failed", re);
            throw re;
        }
    }
    
    public s merge(s detachedInstance) {
        log.debug("merging s instance");
        try {
            s result = entityManager.merge(detachedInstance);
            log.debug("merge successful");
            return result;
        }
        catch (RuntimeException re) {
            log.error("merge failed", re);
            throw re;
        }
    }
    
    public s findById( Dr.textIndex3.sId id) {
        log.debug("getting s instance with id: " + id);
        try {
            s instance = entityManager.find(Dr.textIndex3.s.class, id);
            log.debug("get successful");
            return instance;
        }
        catch (RuntimeException re) {
            log.error("get failed", re);
            throw re;
        }
    }
}

