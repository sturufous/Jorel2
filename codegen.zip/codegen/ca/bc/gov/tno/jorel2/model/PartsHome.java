package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class Parts.
 * @see ca.bc.gov.tno.jorel2.model.Parts
 * @author Hibernate Tools
 */
@Stateless
public class PartsHome {

	private static final Log log = LogFactory.getLog(PartsHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(Parts transientInstance) {
		log.debug("persisting Parts instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(Parts persistentInstance) {
		log.debug("removing Parts instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public Parts merge(Parts detachedInstance) {
		log.debug("merging Parts instance");
		try {
			Parts result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public Parts findById(BigDecimal id) {
		log.debug("getting Parts instance with id: " + id);
		try {
			Parts instance = entityManager.find(Parts.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
