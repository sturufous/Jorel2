package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final


import Dr.contentIndex3.n;
import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class n.
 * @see ca.bc.gov.tno.jorel2.model.Dr.contentIndex3.n
 * @author Hibernate Tools
 */
@Stateless
public class nHome {

    private static final Log log = LogFactory.getLog(Dr.contentIndex3.nHome.class);

    @PersistenceContext private EntityManager entityManager;
    
    public void persist(n transientInstance) {
        log.debug("persisting n instance");
        try {
            entityManager.persist(transientInstance);
            log.debug("persist successful");
        }
        catch (RuntimeException re) {
            log.error("persist failed", re);
            throw re;
        }
    }
    
    public void remove(n persistentInstance) {
        log.debug("removing n instance");
        try {
            entityManager.remove(persistentInstance);
            log.debug("remove successful");
        }
        catch (RuntimeException re) {
            log.error("remove failed", re);
            throw re;
        }
    }
    
    public n merge(n detachedInstance) {
        log.debug("merging n instance");
        try {
            n result = entityManager.merge(detachedInstance);
            log.debug("merge successful");
            return result;
        }
        catch (RuntimeException re) {
            log.error("merge failed", re);
            throw re;
        }
    }
    
    public n findById( BigDecimal id) {
        log.debug("getting n instance with id: " + id);
        try {
            n instance = entityManager.find(Dr.contentIndex3.n.class, id);
            log.debug("get successful");
            return instance;
        }
        catch (RuntimeException re) {
            log.error("get failed", re);
            throw re;
        }
    }
}

