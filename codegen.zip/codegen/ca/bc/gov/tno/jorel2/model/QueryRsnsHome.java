package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class QueryRsns.
 * @see ca.bc.gov.tno.jorel2.model.QueryRsns
 * @author Hibernate Tools
 */
@Stateless
public class QueryRsnsHome {

	private static final Log log = LogFactory.getLog(QueryRsnsHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(QueryRsns transientInstance) {
		log.debug("persisting QueryRsns instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(QueryRsns persistentInstance) {
		log.debug("removing QueryRsns instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public QueryRsns merge(QueryRsns detachedInstance) {
		log.debug("merging QueryRsns instance");
		try {
			QueryRsns result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public QueryRsns findById(QueryRsnsId id) {
		log.debug("getting QueryRsns instance with id: " + id);
		try {
			QueryRsns instance = entityManager.find(QueryRsns.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
