package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class ImportDefinitions.
 * @see ca.bc.gov.tno.jorel2.model.ImportDefinitions
 * @author Hibernate Tools
 */
@Stateless
public class ImportDefinitionsHome {

	private static final Log log = LogFactory.getLog(ImportDefinitionsHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(ImportDefinitions transientInstance) {
		log.debug("persisting ImportDefinitions instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(ImportDefinitions persistentInstance) {
		log.debug("removing ImportDefinitions instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public ImportDefinitions merge(ImportDefinitions detachedInstance) {
		log.debug("merging ImportDefinitions instance");
		try {
			ImportDefinitions result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public ImportDefinitions findById(BigDecimal id) {
		log.debug("getting ImportDefinitions instance with id: " + id);
		try {
			ImportDefinitions instance = entityManager.find(ImportDefinitions.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
