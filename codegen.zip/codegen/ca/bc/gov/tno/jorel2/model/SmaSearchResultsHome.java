package ca.bc.gov.tno.jorel2.model;
// Generated Dec 24, 2019, 8:06:31 AM by Hibernate Tools 5.0.6.Final

import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class SmaSearchResults.
 * @see ca.bc.gov.tno.jorel2.model.SmaSearchResults
 * @author Hibernate Tools
 */
@Stateless
public class SmaSearchResultsHome {

	private static final Log log = LogFactory.getLog(SmaSearchResultsHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(SmaSearchResults transientInstance) {
		log.debug("persisting SmaSearchResults instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(SmaSearchResults persistentInstance) {
		log.debug("removing SmaSearchResults instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public SmaSearchResults merge(SmaSearchResults detachedInstance) {
		log.debug("merging SmaSearchResults instance");
		try {
			SmaSearchResults result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public SmaSearchResults findById(BigDecimal id) {
		log.debug("getting SmaSearchResults instance with id: " + id);
		try {
			SmaSearchResults instance = entityManager.find(SmaSearchResults.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
